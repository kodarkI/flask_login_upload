import datetime

from flask import request, redirect, url_for, render_template, flash,g

from flask_peewee.utils import get_object_or_404, object_list

from app import app
from auth import auth
from models import User, Message, Relationship,user_path
from flask_autoindex import AutoIndex
from peewee import *
from werkzeug.utils import secure_filename
import os 

@app.route('/')
def homepage():
    if auth.get_logged_in_user():
        return private_timeline()
    else:
        return public_timeline()


spath = "/default"
files_index = AutoIndex(app,browse_root=spath, add_url_rules=False)
# Custom indexing
@app.route('/files')
@app.route('/files/')
@app.route('/files/<path:path>')
@auth.login_required
def autoindex(path='.'):
    logged_in_user = str(auth.get_logged_in_user())
            # Check if user has any user_path entries
    has_user_paths = (User
                        .select(fn.EXISTS(user_path.select().where(user_path.user == User.id)))
                        .where(User.username == logged_in_user))

    if not has_user_paths.scalar():
        flash(f'No file paths found for {logged_in_user} account!', 'warning')
        return private_timeline()  # Assuming private_timeline() exists

# Join the tables and select username and u_path
    query = (User
            .select(User.username, user_path.u_path)
            .join(user_path, JOIN.LEFT_OUTER)
            .where(User.username == logged_in_user))
# Get the browse root path for the logged-in user
    for row in query:
        print(row.username, row.user_path.u_path)
        split_text = row.user_path.u_path.split(",")
        spath = split_text[0]
    #return files_index.render_autoindex(path)
    return files_index.render_autoindex(path,browse_root = spath, template='autoindex.html')




@app.route('/upload', methods=['GET', 'POST'])
@auth.login_required
def upload():
    if request.method == 'GET':
        logged_in_user = str(auth.get_logged_in_user())

        try:
            # Check if user has any user_path entries
            has_user_paths = (User
                              .select(fn.EXISTS(user_path.select().where(user_path.user == User.id)))
                              .where(User.username == logged_in_user))

            if not has_user_paths.scalar():
                flash(f'No upload paths found for {logged_in_user} account!', 'warning')
                return private_timeline()  # Assuming private_timeline() exists

            query = (User
                    .select(User.username, user_path.u_pathname, user_path.u_path)
                    .join(user_path, JOIN.LEFT_OUTER)
                    .where(User.username == logged_in_user))

            user_path_data = []
            for row in query:
                user_path_data.append({
                    'path': row.user_path.u_path,
                    'path_name': row.user_path.u_pathname
                })
            # user_paths.sort()  # Assuming user_paths is not needed

        except Exception as e:  # Catch any exceptions during database operations
            flash(f'An error occurred while fetching user paths: {str(e)}', 'error')
            return redirect(url_for('some_default_page'))  # Redirect to a safe page

        return render_template('upload.html', user_path_data=user_path_data)

    else:
        try:
            spath = request.form.get('user_path')  # Get selected path from dropdown
            files = request.files.getlist("file")
            upload_folder = spath
            for file in files:
                filename = secure_filename(file.filename)
                file_path = os.path.join(upload_folder, filename)
                file.save(file_path)
            flash('Files Uploaded Successfully!', 'success')
            return redirect(url_for('upload'))
        except Exception as e:  # Catch any exceptions during file upload
            flash(f'An error occurred during file upload: {str(e)}', 'error')
            return redirect(url_for('upload'))  # Redirect back to the upload page


""" 
@app.route('/upload', methods=['GET', 'POST'])
@auth.login_required
def upload():
    if request.method == 'GET':
        logged_in_user = str(auth.get_logged_in_user())     

                # Check if user has any user_path entries
        has_user_paths = (User
                          .select(fn.EXISTS(user_path.select().where(user_path.user == User.id)))
                          .where(User.username == logged_in_user))

        if not has_user_paths.scalar():
            flash(f'No upload paths found for {logged_in_user} account!', 'warning')
            return private_timeline()  # Assuming private_timeline() exists

        query = (User
         .select(User.username, user_path.u_pathname, user_path.u_path)
         .join(user_path, JOIN.LEFT_OUTER)
         .where(User.username == logged_in_user))
        
        
        user_path_data = []  # List of dictionaries for user path data
        for row in query:
            user_path_data.append({
                'path': row.user_path.u_path,
                'path_name': row.user_path.u_pathname
            })
        #user_paths.sort()

        return render_template('upload.html', user_path_data=user_path_data)
    else:
        spath = request.form.get('user_path')  # Get selected path from dropdown
        files = request.files.getlist("file")
        upload_folder = spath
        for file in files:
            filename = secure_filename(file.filename)
            file_path = os.path.join(upload_folder, filename)
            file.save(file_path)
        flash('Files Uploaded Successfully!', 'success')
        return redirect(url_for('upload'))
 """

@app.route('/private/')
@auth.login_required
def private_timeline():
    user = auth.get_logged_in_user()

    messages = Message.select().where(
        Message.user << user.following()
    ).order_by(Message.pub_date.desc())

    return object_list('private_messages.html', messages, 'message_list')

@app.route('/public/')
def public_timeline():
    messages = Message.select().order_by(Message.pub_date.desc())
    return object_list('public_messages.html', messages, 'message_list')

@app.route('/join/', methods=['GET', 'POST'])
def join():
    if request.method == 'POST' and request.form['username']:
        try:
            user = User.select().where(User.username==request.form['username']).get()
            flash('That username is already taken')
        except User.DoesNotExist:
            user = User(
                username=request.form['username'],
                #email=request.form['email'],
                join_date=datetime.datetime.now()
            )
            #user.set_password(request.form['password'])
            user.save()

            auth.login_user(user)
            return redirect(url_for('homepage'))

    return render_template('join.html')

@app.route('/following/')
@auth.login_required
def following():
    user = auth.get_logged_in_user()
    return object_list('user_following.html', user.following(), 'user_list')

@app.route('/followers/')
@auth.login_required
def followers():
    user = auth.get_logged_in_user()
    return object_list('user_followers.html', user.followers(), 'user_list')

@app.route('/users/')
def user_list():
    users = User.select().order_by(User.username)
    return object_list('user_list.html', users, 'user_list')

@app.route('/users/<username>/')
def user_detail(username):
    user = get_object_or_404(User, User.username==username)
    messages = user.message_set.order_by(Message.pub_date.desc())
    return object_list('user_detail.html', messages, 'message_list', person=user)

@app.route('/users/<username>/follow/', methods=['POST'])
@auth.login_required
def user_follow(username):
    user = get_object_or_404(User, User.username==username)
    Relationship.get_or_create(
        from_user=auth.get_logged_in_user(),
        to_user=user,
    )
    flash('You are now following %s' % user.username)
    return redirect(url_for('user_detail', username=user.username))

@app.route('/users/<username>/unfollow/', methods=['POST'])
@auth.login_required
def user_unfollow(username):
    user = get_object_or_404(User, User.username==username)
    Relationship.delete().where(
        Relationship.from_user==auth.get_logged_in_user(),
        Relationship.to_user==user,
    ).execute()
    flash('You are no longer following %s' % user.username)
    return redirect(url_for('user_detail', username=user.username))

@app.route('/create/', methods=['GET', 'POST'])
@auth.login_required
def create():
    user = auth.get_logged_in_user()
    if request.method == 'POST' and request.form['content']:
        message = Message.create(
            user=user,
            content=request.form['content'],
        )
        flash('Your message has been created')
        return redirect(url_for('user_detail', username=user.username))

    return render_template('create.html')

@app.route('/edit/<int:message_id>/', methods=['GET', 'POST'])
@auth.login_required
def edit(message_id):
    user = auth.get_logged_in_user()
    message = get_object_or_404(Message, Message.user==user, Message.id==message_id)
    if request.method == 'POST' and request.form['content']:
        message.content = request.form['content']
        message.save()
        flash('Your changes were saved')
        return redirect(url_for('user_detail', username=user.username))

    return render_template('edit.html', message=message)
