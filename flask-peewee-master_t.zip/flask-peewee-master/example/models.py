from hashlib import md5
import datetime

from flask_peewee.auth import BaseUser
from peewee import *

from app import db


class User(db.Model, BaseUser):
    username = CharField()
    join_date = DateTimeField(default=datetime.datetime.now)
    active = BooleanField(default=True)
    admin = BooleanField(default=False)

    def __str__(self):
        return self.username

    def following(self):
        return User.select().join(
            Relationship, on=Relationship.to_user
        ).where(Relationship.from_user==self).order_by(User.username)

    def followers(self):
        return User.select().join(
            Relationship, on=Relationship.from_user
        ).where(Relationship.to_user==self).order_by(User.username)

    def is_following(self, user):
        return Relationship.select().where(
            Relationship.from_user==self,
            Relationship.to_user==user
        ).exists()

class Relationship(db.Model):
    from_user = ForeignKeyField(User, related_name='relationships')
    to_user = ForeignKeyField(User, related_name='related_to')

    def __str__(self):
        return 'Relationship from %s to %s' % (self.from_user, self.to_user)


""" class Paths(db.Model):
    user = ForeignKeyField(User)
    path_content = TextField()
    pub_date = DateTimeField(default=datetime.datetime.now)

    def __str__(self):
        return '%s: %s' % (self.user, self.path_content) """

class Message(db.Model):
    user = ForeignKeyField(User)
    content = TextField()
    pub_date = DateTimeField(default=datetime.datetime.now)

    def __str__(self):
        return '%s: %s' % (self.user, self.content)


class user_path(db.Model):
    user = ForeignKeyField(User)
    u_pathname = CharField()
    u_path = TextField()
    pub_date = DateTimeField(default=datetime.datetime.now)

    def __str__(self):
        return '%s: %s' % (self.user, self.u_path)
    
""" class user_path(db.Model):
    user = ForeignKeyField(User, unique=True)  # Ensure uniqueness for the user
    u_path = TextField()
    pub_date = DateTimeField(default=datetime.datetime.now)
    
    def __str__(self):
        return '%s: %s' % (self.user, self.u_path)

    class Meta:
        # Define a composite unique constraint on (user, u_path)
        indexes = (
            (('user', 'u_path'), True),  # Ensure the combination is unique
        )

 """

class Note(db.Model):
    user = ForeignKeyField(User)
    message = TextField()
    status = IntegerField(choices=((1, 'live'), (2, 'deleted')), null=True)
    created_date = DateTimeField(default=datetime.datetime.now)


def create_tables():
    User.create_table()
    Relationship.create_table()
    Message.create_table()
    Note.create_table()
    user_path.create_table()


create_tables()

#db.create_tables([User,Relationship,Message,Note,user_path])
#Testing

rows=user_path.select()
print (rows.sql())
for row in rows:
   print ("name: {} active: {}".format(row.user_id, row.u_path))


# Join the tables and select username, u_pathname, and u_path
query = (User
         .select(User.username, user_path.u_pathname, user_path.u_path)
         .join(user_path, JOIN.LEFT_OUTER)
         .where(User.username == 'test'))

# Execute the query and print the result
for row in query:
    print(row.username, row.user_path.u_path)

""" query = (User
         .select(User.username, user_path.u_pathname, user_path.u_path)
         .join(user_path, JOIN.LEFT_OUTER)
         .where(User.username == 'admin'))

# Execute the query and print the result
for row in query:
    print(row.username, getattr(row.user_path, 'u_pathname', None), getattr(row.user_path, 'u_path', None))
 """