########################################################################################
######################          Import packages      ###################################
########################################################################################
from flask import Blueprint, render_template, flash,request ,current_app, flash,redirect,url_for,session, jsonify
from flask_login import login_required, current_user
from __init__ import create_app, db
from flask_autoindex import AutoIndex
from werkzeug.utils import secure_filename
import os 
########################################################################################


def doRender(tname, values={}):
    if not os.path.isfile( os.path.join(os.getcwd(), 'templates/'+tname) ): #No such file
        return render_template('index.html')
    return render_template(tname, **values) 


# our main blueprint
main = Blueprint('main', __name__)


@main.route('/') # home page that return 'index'
def index():
    return render_template('index.html')

@main.route('/profile') # profile page that return 'profile'
@login_required
def profile():
    return render_template('profile.html', name=current_user.name)

@main.route('/upload', methods=['GET', 'POST']) 
@login_required
def upload(): 
	if request.method=='GET': # if the request is a GET we return the login page
		return render_template('upload.html')
	else : 
		files = request.files.getlist("file") 
		upload_folder = current_app.config['UPLOAD_FOLDER']
		for file in files: 
			filename = secure_filename(file.filename)
			file_path = os.path.join(upload_folder, filename)
			file.save(file_path)
			#file.save(os.path.join(upload_folder,file.filename))
			#file.save(os.path.join(app.config['UPLOAD_FOLDER'], file.filename))
#		return "<h1>Files Uploaded Successfully.!</h1>"
		flash('Files Uploaded Successfully!', 'success')
		return redirect(url_for('main.upload')) 
  
spath = "/Users/ponlasitpoopipatpol/Downloads/Create_LoginPage-main"
files_index = AutoIndex(main,browse_root=spath, add_url_rules=False)
# Custom indexing
@main.route('/files')
@main.route('/files/')
@main.route('/files/<path:path>')
@login_required
def autoindex(path='.'):
    #return files_index.render_autoindex(path)
    return files_index.render_autoindex(path, template='autoindex.html')


# catch all other page requests - doRender checks if a page is available (shows it) or not (index)
@main.route('/', defaults={'path': ''})
@main.route('/<path:path>')
def mainPage(path):
    return doRender(path)

@main.route('/logout2', methods=['POST'])
def logout():
    # Clear session variables on logout
    session.clear()
    return jsonify({'message': 'Logged out'}), 200

app = create_app() # we initialize our flask app using the __init__.py function
if __name__ == '__main__':
    with app.app_context():
        db.create_all() # create the SQLite database
    app.run(debug=True) # run the flask app on debug mode
