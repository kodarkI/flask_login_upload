from flask import Flask 
from flask_autoindex import AutoIndex
import os

app = Flask(__name__)

spath = "/Users/ponlasitpoopipatpol/Downloads/Create_LoginPage-main"
files_index = AutoIndex(app,browse_root=spath, add_url_rules=False)
# Custom indexing
@app.route('/files')
@app.route('/files/<path:path>')
def autoindex(path='.'):
    #return files_index.render_autoindex(path)
    return files_index.render_autoindex(path, template='autoindex.html')

if __name__ == "__main__":
    app.run()

    