# Version 0.6.6

- #29 Hide milisecond in Last modified column
- Update the doc : FAI is no more supported on python 3.5 because the Flask dependancy (use f-string)

# Version 0.6.5

- Update the dependency from werkzeug (thanks to @jardon)
