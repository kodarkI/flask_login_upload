from flask import g, url_for, redirect, request
from wtforms import TextAreaField

from .models import Product, Category, Filepattern, Uploadpath, Role, Userrole, Uploadcontrol
from flask_admin.contrib.sqla import ModelView

from config.database import db_session
from config.settings import admin


class AdminModelView(ModelView):

    def is_accessible(self):
        if g.user.is_authenticated:
            return g.user.is_admin

    def inaccessible_callback(self, name, **kwargs):
        return redirect(url_for('login', next=request.endpoint))


class ProductView(AdminModelView):
    column_exclude_list = ['description']
    can_create = True
    can_view_details = True

    form_overrides = dict(description=TextAreaField)


admin.add_view(AdminModelView(Category,
                              db_session,
                              name="categories",
                              menu_icon_type="fa",
                              menu_icon_value="fa-list"))
admin.add_view(ProductView(Product, db_session,
                           name="products",
                           menu_icon_type="fa",
                           menu_icon_value="fa-database"))

class AdminFilepatternView(ModelView):
    column_list = ['file_name', 'file_format', 'uploadcontrols']  # Columns to display
    column_labels = {'File_name': 'File Name', 'File_format': 'File Format'}  # Custom column labels
    
    def _uploadcontrols_formatter(view, context, model, name):
        return ', '.join(uploadcontrol.uploadcontrol_name for uploadcontrol in model.uploadcontrols)
    
    column_formatters = {
        'uploadcontrols': _uploadcontrols_formatter
    }

# Then add the view to your admin
admin.add_view(AdminFilepatternView(Filepattern,
                                    db_session,
                                    name="Filepatterns",
                                    menu_icon_type="fa",
                                    menu_icon_value="fa-list"))



class AdminUploadView(ModelView):
    column_list = ['path_name', 'path', 'description', 'uploadcontrols']  # Columns to display
    column_labels = {'path_name': 'Path Name', 'path': 'Path'}  # Custom column labels
    
    def _uploadcontrols_formatter(view, context, model, name):
        return ', '.join(uploadcontrol.uploadcontrol_name for uploadcontrol in model.uploadcontrols)
    
    column_formatters = {
        'uploadcontrols': _uploadcontrols_formatter
    }

# Then add the view to your admin
admin.add_view(AdminUploadView(Uploadpath,
                               db_session,
                               name="Uploadpath",
                               menu_icon_type="fa",
                               menu_icon_value="fa-list"))




class AdminUploadcontrolView(ModelView):
    column_list = ['uploadcontrol_name', 'description', 'file_names', 'upload_paths']  # Columns to display
    column_labels = {'uploadcontrol_name': 'Upload Control Name', 'description': 'Description'}  # Custom column labels
    
    def _file_names_formatter(view, context, model, name):
        return ', '.join(filepattern.file_name for filepattern in model.filepatterns)
    
    def _upload_paths_formatter(view, context, model, name):
        return ', '.join(uploadpath.path_name for uploadpath in model.uploadpaths)
    
    column_formatters = {
        'file_names': _file_names_formatter,
        'upload_paths': _upload_paths_formatter
    }

# Then add the view to your admin
admin.add_view(AdminUploadcontrolView(Uploadcontrol,
                                       db_session,
                                       name="Upload Controls",
                                       menu_icon_type="fa",
                                       menu_icon_value="fa-upload"))

class AdminRoleView(ModelView):
    column_list = ['role_name', 'description', 'uploadcontrol_names']  # Columns to display
    column_labels = {'role_name': 'Role Name', 'description': 'Description'}  # Custom column labels
    
    def _uploadcontrol_names_formatter(view, context, model, name):
        return ', '.join(uploadcontrol.uploadcontrol_name for uploadcontrol in model.uploadcontrols)
    
    column_formatters = {
        'uploadcontrol_names': _uploadcontrol_names_formatter
    }

# Then add the view to your admin
admin.add_view(AdminRoleView(Role,
                              db_session,
                              name="Roles",
                              menu_icon_type="fa",
                              menu_icon_value="fa-user"))



admin.add_view(AdminModelView(Userrole,
                              db_session,
                              name="Userrole",
                              menu_icon_type="fa",
                              menu_icon_value="fa-list"))