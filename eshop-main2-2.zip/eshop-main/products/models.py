from sqlalchemy import *
from sqlalchemy.orm import relationship, backref

from auth.models import User
from config.database import Base


class Category(Base):
    __tablename__ = "category"
    id = Column(Integer, primary_key=True)
    name = Column(String(200))

    def __str__(self):
        return f"{self.name}"


class Product(Base):
    __tablename__ = "product"
    id = Column(Integer, primary_key=True)
    name = Column(String(200), unique=True)
    description = Column(String(1000))
    price = Column(Float())
    quantity = Column(Integer())
    path = Column(String(200))
    owner_id = Column(Integer, ForeignKey(User.id), nullable=False)
    owner = relationship(User, backref=backref('products', lazy=True))
    category_id = Column(Integer, ForeignKey(Category.id), nullable=False)
    category = relationship(Category, backref=backref('products', lazy=True))

    def __str__(self):
        return f'{self.name} - {self.price}'


uploadcontrol_role = Table(
    "uploadcontrol_role",
    Base.metadata,
    Column("uploadcontrol_id", ForeignKey("uploadcontrol.id"), primary_key=True),
    Column("role_id", ForeignKey("role.id"), primary_key=True),
)

filepattern_uploadcontrol = Table(
    "filepattern_uploadcontrol",
    Base.metadata,
    Column("filepattern_id", ForeignKey("filepattern.id"), primary_key=True),
    Column("uploadcontrol_id", ForeignKey("uploadcontrol.id"), primary_key=True),
)

uploadpath_uploadcontrol = Table(
    "uploadpath_uploadcontrol",
    Base.metadata,
    Column("uploadpath_id", ForeignKey("uploadpath.id"), primary_key=True),
    Column("uploadcontrol_id", ForeignKey("uploadcontrol.id"), primary_key=True),
)


class Uploadcontrol(Base):
    __tablename__ = "uploadcontrol"
    id = Column(Integer, primary_key=True)
    uploadcontrol_name = Column(String(200), unique=True)
    description = Column(String(1000))
    roles = relationship("Role", secondary=uploadcontrol_role, back_populates="uploadcontrols")
    filepatterns = relationship("Filepattern", secondary=filepattern_uploadcontrol, back_populates="uploadcontrols")
    uploadpaths = relationship("Uploadpath", secondary=uploadpath_uploadcontrol, back_populates="uploadcontrols")

    def __str__(self):
        return f"{self.uploadcontrol_name}"


class Role(Base):
    __tablename__ = "role"
    id = Column(Integer, primary_key=True)
    role_name = Column(String(200), unique=True)
    description = Column(String(1000))
    uploadcontrols = relationship("Uploadcontrol", secondary=uploadcontrol_role, back_populates="roles")

    def __str__(self):
        return f"{self.role_name}"


class Filepattern(Base):
    __tablename__ = "filepattern"
    id = Column(Integer, primary_key=True)
    file_name = Column(String(200), unique=True)
    file_format = Column(String(1000))
    uploadcontrols = relationship("Uploadcontrol", secondary=filepattern_uploadcontrol, back_populates="filepatterns")

    def __repr__(self):
        return f"{self.file_name}"


class Uploadpath(Base):
    __tablename__ = "uploadpath"
    id = Column(Integer, primary_key=True)
    path_name = Column(String(200), unique=True)
    path = Column(String(200))
    description = Column(String(1000))
    uploadcontrols = relationship("Uploadcontrol", secondary=uploadpath_uploadcontrol, back_populates="uploadpaths")

    def __str__(self):
        return f"{self.path_name}"


class Userrole(Base):
    __tablename__ = "userrole"
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("user.id"), nullable=False)
    user = relationship("User", backref="userroles")
    role_id = Column(Integer, ForeignKey("role.id"), nullable=False)
    role = relationship("Role", backref="userroles")

    def __init__(self, user, role):
        self.user = user
        self.role = role

    def __str__(self):
        return f"UserRole(user={self.user}, role={self.role})"