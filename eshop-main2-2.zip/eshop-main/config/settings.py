from flask import Flask, g, url_for, request, redirect, flash
from flask_admin import Admin, AdminIndexView, expose
from flask_graphql_auth import GraphQLAuth
from flask_login import LoginManager, current_user
from graphene_file_upload.flask import FileUploadGraphQLView

from auth.models import User
from products.models import Userrole, Role, Filepattern, Uploadpath, Uploadcontrol
from .database import db_session
from sqlalchemy.orm import sessionmaker, aliased
from .database import engine, Base
from .schema import schema

app = Flask(__name__)

secret = "jh876867g66236990990909%16777#ff992n623TG33fg545455"
app.config['JWT_SECRET_KEY'] = secret
app.config['FLASK_ADMIN_FLUID_LAYOUT'] = True
app.config['SECRET_KEY'] = secret
app.config['REFRESH_EXP_LENGTH'] = 30
app.config["ACCESS_EXP_LENGTH"] = 10
app.config['JWT_SECRET_KEY'] = "Bearer"

auth = GraphQLAuth(app)

login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'


@app.before_request
def before_req():
    g.user = current_user


@login_manager.user_loader
def user_loader(id):
    return User.query.get(int(id))


app.add_url_rule("/graphql",
                 view_func=FileUploadGraphQLView.as_view(
                     "graphql",
                     schema=schema,
                     graphiql=True
                 ))

app.config['FLASK_ADMIN_SWATCH'] = 'cerulean'


# class MyAdminIndexView(AdminIndexView):
#     @expose("/")
#     def index(self):
#         if g.user.is_authenticated:
#             if g.user.is_admin:
#                 return super(MyAdminIndexView,self).index()
#         next_url = request.endpoint
#         login_url = '%s?next=%s' % (url_for('login'), next_url)
#         flash('Please login as admin  first...', 'error')
#         return redirect(login_url)

class MyAdminIndexView(AdminIndexView):
    @expose("/")
    def index(self):
        print("Current user:", current_user)
        
        # # Create session
        Session = sessionmaker(bind=engine)
        session = Session()

        # # Define the user ID you want to retrieve information for
        # user_id = 1  # Change this to the desired user ID

        # # Query to join User with Userrole, Role, Filepattern, and Uploadpath
        # results = session.query(User, Filepattern.File_name, Filepattern.File_format, Uploadpath.path_name, Uploadpath.path)\
        #     .join(User.userroles)\
        #     .join(Userrole.role)\
        #     .join(Role.files)\
        #     .join(Role.uploads)\
        #     .join(Filepattern, Role.files)\
        #     .join(Uploadpath, Role.uploads)\
        #     .filter(User.id == user_id)\
        #     .all()  # Retrieve all rows

        # # Iterate over the results
        # for user, file_name, file_format, path_name, path in results:
        #     print(f"User: {user.username}, File: {file_name}, Format: {file_format}, Path Name: {path_name}, Path: {path}")

        # Query users with their associated file names and path names
        # Create aliases for tables

        # Query users along with their associated file_name and path_name
        # Query users along with their associated role name and upload control name
        users_with_roles_and_uploadcontrols = session.query(User.username, Role.role_name, Uploadcontrol.uploadcontrol_name)\
            .join(Userrole, User.id == Userrole.user_id)\
            .join(Role, Userrole.role_id == Role.id)\
            .join(Uploadcontrol, Role.uploadcontrols)\
            .all()

        # Print the result
        for username, role_name, uploadcontrol_name in users_with_roles_and_uploadcontrols:
            print(f"User: {username}, Role: {role_name}, Upload Control: {uploadcontrol_name}")

        # Query users along with their associated details
        users_with_details = session.query(User.username, Role.role_name, Uploadcontrol.uploadcontrol_name,
                                        Filepattern.file_name, Uploadpath.path_name)\
            .join(Userrole, User.id == Userrole.user_id)\
            .join(Role, Userrole.role_id == Role.id)\
            .join(Uploadcontrol, Role.uploadcontrols)\
            .join(Filepattern, Uploadcontrol.filepatterns)\
            .join(Uploadpath, Uploadcontrol.uploadpaths)\
            .all()

        # Print the result
        for username, role_name, uploadcontrol_name, file_name, path_name in users_with_details:
            print(f"User: {username}, Role: {role_name}, Upload Control: {uploadcontrol_name}, File Name: {file_name}, Path Name: {path_name}")


        if current_user.is_authenticated:
            if current_user.is_admin:
                return super(MyAdminIndexView, self).index()
            else:
                print("Non-admin user detected. Redirecting to index page.")
                return redirect(url_for('index'))  # Replace 'index' with your actual endpoint
        else:
            print("Unauthenticated user detected. Redirecting to index page.")
            return redirect(url_for('index'))  # Replace 'index' with your actual endpoint

admin = Admin(app, name='eshop', template_mode='bootstrap4', index_view=MyAdminIndexView(
    name="Dashboard", menu_icon_type="fa", menu_icon_value="fa-dashboard"
))


@app.teardown_appcontext
def shutdown_session(exception=None):
    db_session.remove()
