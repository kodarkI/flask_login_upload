from flask_admin.contrib.sqla import ModelView

from config.database import db_session
from config.settings import admin
from .models import User
from wtforms.fields import SelectField
from flask_admin.form import Select2Widget

class AdminUserView(ModelView):
    column_list = ['username', 'email', 'is_admin', 'verified']  # Columns to display
    column_labels = {'username': 'Username', 'email': 'Email', 'is_admin': 'Is Admin', 'verified': 'Verified'}  # Custom column labels
    column_editable_list = ('is_admin', 'verified')
    
    def _is_admin_formatter(view, context, model, name):
        return 'Yes' if model.is_admin else 'No'
    
    def _verified_formatter(view, context, model, name):
        return 'Yes' if model.verified else 'No'
    
    column_formatters = {
        'is_admin': _is_admin_formatter,
        'verified': _verified_formatter
    }
    
    column_formatters_detail = {
        'is_admin': lambda v, c, m, p: m.is_admin,
        'verified': lambda v, c, m, p: m.verified,
    }
    
    column_formatters_export = {
        'is_admin': lambda v, c, m, p: m.is_admin,
        'verified': lambda v, c, m, p: m.verified,
    }

# Then add the view to your admin
admin.add_view(AdminUserView(User,
                             db_session,
                             name="Users",
                             menu_icon_type="fa",
                             menu_icon_value="fa-users"))
