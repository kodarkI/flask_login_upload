from auth.views import *
from auth.admin import *
from products.admin import *
from config.database import engine, Base

Base.metadata.create_all(bind=engine)

# You can import and use your models here
from auth.models import User

if __name__ == '__main__':
    app.run()
