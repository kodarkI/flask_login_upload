from flask_admin.contrib.sqla import ModelView

from config.database import db_session
from config.settings import admin
from .models import User
from wtforms import SelectField

class UserAdminView(ModelView):
    column_list = ['id', 'username', 'email', 'is_admin', 'verified']  # List of columns to display in the table view

    # Customize the edit form for the boolean columns to use dropdowns
    form_overrides = {
        'is_admin': SelectField,
        'verified': SelectField
    }

    # Customize the choices for the boolean columns
    form_args = {
        'is_admin': {
            'choices': [(True, 'Yes'), (False, 'No')]
        },
        'verified': {
            'choices': [(True, 'Yes'), (False, 'No')]
        }
    }


admin.add_view(UserAdminView(User, db_session, name="users", menu_icon_type="fa", menu_icon_value="fa-users"))
